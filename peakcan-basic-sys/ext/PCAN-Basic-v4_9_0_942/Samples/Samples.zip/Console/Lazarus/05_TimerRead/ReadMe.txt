No Timer class:
~~~~~~~~~~~~~~~

Since there is no timer class in the environemnt used for the sample project, a timer is actually implemented by using a thread.
In order to check how a thread is used, please refer to the sample project "07_ThreadRead".

PEAK-Team